#!/bin/sh

NSAM=4194304

build_nodes() {
	finit=0
	while [ $finit -eq 0 ]; do
		read M_DEV
		if [ "$M_DEV" = "" ]; then
			finit=1;
		else
			MAJOR=${M_DEV% *}
			NAME=${M_DEV#* }		
			ID=${M_DEV#*.}

			mknod /dev/ACQ420_FMC${ID} c ${MAJOR} 0
			mknod /dev/${NAME} c ${MAJOR} 0
		fi
	done
}


lsmod | grep -q acq420FMC
notloaded=$?

if [ $notloaded -ne 0 ]; then
	if [ -f /mnt/acq420FMC.ko ]; then
		cp /mnt/acq420FMC.ko /lib/modules/d-tacq/acq420FMC.ko
	fi

	insmod /lib/modules/d-tacq/acq420FMC.ko
	grep acq420 /proc/devices |  build_nodes
	ln -s /sys/bus/platform/devices/40001000.ACQ420_FMC/ /dev/acq420.0.knobs

	echo 200 >/dev/acq420.0.knobs/clkdiv
	echo 0000 >/dev/acq420.0.knobs/gains
fi

inetd /mnt/inetd.conf


